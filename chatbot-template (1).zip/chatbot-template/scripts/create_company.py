#!/usr/bin/env python3
"""
create_company.py
====================
Company scaffolding generator.

Give it a short company CODE (e.g. "data-ch", "acme", "designerhub")
and a display name, and it creates a brand-new, fully working company
folder under `companies/<code>/` containing:

    companies/<code>/theme.py
    companies/<code>/data/company_data.txt

...ready for you to fill in and point COMPANY_CODE=<code> at in .env.
No other project files need to be touched.

USAGE
-----
    python scripts/create_company.py <code> "<Company Name>"

EXAMPLES
--------
    python scripts/create_company.py data-ch "Data Chatbot Inc"
    python scripts/create_company.py acme "Acme Corporation"

After running, the script prints exactly what to do next.
"""

import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
COMPANIES_DIR = PROJECT_ROOT / "companies"

CODE_PATTERN = re.compile(r"^[a-z0-9][a-z0-9\-_]*$")

THEME_TEMPLATE = '''"""
companies/{code}/theme.py
=========================
Global branding/theme configuration for {company_name}.

Edit these values to rebrand the chatbot. Every field here is
automatically picked up by the frontend via GET /theme - no HTML/CSS/JS
changes are ever required.
"""

# Branding
COMPANY_NAME = "{company_name}"
BOT_NAME = "Assistant"
LOGO_PATH = "/static/images/logo.png"
CHAT_ICON = "\U0001F4AC"

# Colors (used as CSS variables by the frontend)
PRIMARY_COLOR = "#4F46E5"
SECONDARY_COLOR = "#818CF8"
BACKGROUND_COLOR = "#F9FAFB"

# Typography
FONT_FAMILY = "'Inter', 'Segoe UI', sans-serif"

# Copy
WELCOME_MESSAGE = "Hi! How can I help you today?"
FOOTER_TEXT = "Powered by {company_name} AI"
'''

DATA_TEMPLATE = """Company Name: {company_name}

CEO:

Email:

Phone:

Office Address:

Working Hours:

Products:
-

Services:
-

Return Policy:


FAQs:

Q:
A:
"""


def slugify_check(code: str) -> str:
    """Validate and normalize the company code."""
    code = code.strip().lower()
    if not CODE_PATTERN.match(code):
        print(
            f"Error: '{code}' is not a valid company code.\n"
            f"Use lowercase letters, numbers, hyphens, or underscores "
            f"(e.g. 'data-ch', 'acme_corp')."
        )
        sys.exit(1)
    return code


def create_company(code: str, company_name: str) -> None:
    """Create the companies/<code>/ folder with theme.py + data file."""
    company_dir = COMPANIES_DIR / code
    data_dir = company_dir / "data"

    if company_dir.exists():
        print(f"Error: companies/{code}/ already exists. Choose a different code.")
        sys.exit(1)

    data_dir.mkdir(parents=True)

    theme_path = company_dir / "theme.py"
    theme_path.write_text(
        THEME_TEMPLATE.format(code=code, company_name=company_name),
        encoding="utf-8",
    )

    data_path = data_dir / "company_data.txt"
    data_path.write_text(
        DATA_TEMPLATE.format(company_name=company_name),
        encoding="utf-8",
    )

    print(f"\n✅ Company '{code}' created successfully!\n")
    print(f"   companies/{code}/theme.py")
    print(f"   companies/{code}/data/company_data.txt\n")
    print("Next steps:")
    print(f"   1. Edit companies/{code}/theme.py to set brand colors, logo, name.")
    print(f"   2. Edit companies/{code}/data/company_data.txt with real company info.")
    print(f"   3. In your .env file, set:")
    print(f"          COMPANY_CODE={code}")
    print("   4. Run the app:  uvicorn app:app --reload\n")


def main() -> None:
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    raw_code = sys.argv[1]
    company_name = sys.argv[2]

    code = slugify_check(raw_code)
    create_company(code, company_name)


if __name__ == "__main__":
    main()
