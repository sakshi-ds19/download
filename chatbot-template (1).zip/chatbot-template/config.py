"""
config.py
=========
Central runtime configuration for the chatbot framework.

Everything here is sourced from environment variables (via a .env file)
so that NO secrets or per-deployment values are ever hardcoded in code.

The single most important setting is COMPANY_CODE: it tells the
framework which folder under `companies/` to load the theme and
knowledge base from. This is what makes the framework "white-label" -
deploying for a new client is just:

    1. scripts/create_company.py <code> "<Company Name>"
    2. edit companies/<code>/theme.py and companies/<code>/data/company_data.txt
    3. set COMPANY_CODE=<code> in .env
    4. run the app

No other code changes are required.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
COMPANIES_DIR = BASE_DIR / "companies"
LOGS_DIR = BASE_DIR / "logs"

# ---------------------------------------------------------------------------
# Active tenant / company
# ---------------------------------------------------------------------------
COMPANY_CODE: str = os.getenv("COMPANY_CODE", "demo")

# ---------------------------------------------------------------------------
# AI Provider selection (future-proofed for OpenAI, Claude, Azure, Ollama...)
# ---------------------------------------------------------------------------
AI_PROVIDER: str = os.getenv("AI_PROVIDER", "gemini").lower()

# Gemini
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

# OpenAI (placeholder for future use, wired via the same interface)
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

# ---------------------------------------------------------------------------
# Networking / server
# ---------------------------------------------------------------------------
HOST: str = os.getenv("HOST", "0.0.0.0")
PORT: int = int(os.getenv("PORT", "8000"))
DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

# ---------------------------------------------------------------------------
# Behavioural limits
# ---------------------------------------------------------------------------
MAX_MESSAGE_LENGTH: int = int(os.getenv("MAX_MESSAGE_LENGTH", "1000"))
AI_TIMEOUT_SECONDS: int = int(os.getenv("AI_TIMEOUT_SECONDS", "20"))
AI_MAX_OUTPUT_TOKENS: int = int(os.getenv("AI_MAX_OUTPUT_TOKENS", "512"))


def get_company_dir(company_code: str | None = None) -> Path:
    """Return the absolute path to a company's data directory.

    Args:
        company_code: Optional override; defaults to the active COMPANY_CODE.

    Returns:
        Path to companies/<company_code>/
    """
    code = company_code or COMPANY_CODE
    return COMPANIES_DIR / code


def setup_logging() -> logging.Logger:
    """Configure and return the application-wide logger.

    Logs to both console and logs/app.log so issues can be diagnosed
    per-deployment without needing external tooling.
    """
    LOGS_DIR.mkdir(exist_ok=True)
    logger = logging.getLogger("chatbot")
    if logger.handlers:
        # Avoid duplicate handlers on reload
        return logger

    logger.setLevel(logging.DEBUG if DEBUG else logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler(LOGS_DIR / "app.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger
