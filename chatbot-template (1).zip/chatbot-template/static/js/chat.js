/**
 * chat.js
 * ========
 * Drives the chatbot widget: fetches the active company's theme,
 * applies it as CSS variables, and handles the chat conversation flow
 * (send message -> show typing indicator -> render AI response).
 *
 * This file is 100% company-agnostic: it never contains a hardcoded
 * company name, color, or message. Everything comes from GET /theme.
 */

(function () {
  "use strict";

  const els = {
    toggleBtn: document.getElementById("chat-toggle-btn"),
    toggleIcon: document.getElementById("chat-toggle-icon"),
    window: document.getElementById("chat-window"),
    closeBtn: document.getElementById("chat-close-btn"),
    messages: document.getElementById("chat-messages"),
    typing: document.getElementById("typing-indicator"),
    form: document.getElementById("chat-form"),
    input: document.getElementById("chat-input"),
    sendBtn: document.getElementById("chat-send-btn"),
    logo: document.getElementById("chat-logo"),
    botName: document.getElementById("chat-bot-name"),
    footer: document.getElementById("chat-footer"),
  };

  let theme = null;
  let isOpen = false;
  let isSending = false;

  /** Apply theme values as CSS custom properties + text content. */
  function applyTheme(t) {
    const root = document.documentElement;
    root.style.setProperty("--chat-primary", t.primary_color);
    root.style.setProperty("--chat-secondary", t.secondary_color);
    root.style.setProperty("--chat-background", t.background_color);
    root.style.setProperty("--chat-font", t.font_family);

    els.toggleIcon.textContent = t.chat_icon || "💬";
    els.botName.textContent = t.bot_name || "Assistant";
    els.footer.textContent = t.footer_text || "";
    if (t.logo_path) els.logo.src = t.logo_path;

    document.title = `${t.company_name || "Chat"} - ${t.bot_name || "Assistant"}`;
  }

  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function appendMessage(text, sender, isError) {
    const wrapper = document.createElement("div");
    wrapper.className = `msg msg--${sender}${isError ? " msg--error" : ""}`;
    const textNode = document.createElement("div");
    textNode.textContent = text;
    const time = document.createElement("span");
    time.className = "msg-time";
    time.textContent = formatTime(new Date());
    wrapper.appendChild(textNode);
    wrapper.appendChild(time);
    els.messages.appendChild(wrapper);
    scrollToBottom();
  }

  function scrollToBottom() {
    els.messages.scrollTop = els.messages.scrollHeight;
  }

  function showTyping(show) {
    els.typing.classList.toggle("typing-indicator--hidden", !show);
    if (show) scrollToBottom();
  }

  function setSending(sending) {
    isSending = sending;
    els.sendBtn.disabled = sending;
    els.input.disabled = sending;
  }

  async function loadTheme() {
    try {
      const res = await fetch("/theme");
      theme = await res.json();
      applyTheme(theme);
      appendMessage(theme.welcome_message || "Hi! How can I help you today?", "bot");
    } catch (err) {
      console.error("Failed to load theme:", err);
      appendMessage("Hi! How can I help you today?", "bot");
    }
  }

  async function sendMessage(text) {
    appendMessage(text, "user");
    setSending(true);
    showTyping(true);

    try {
      const res = await fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      if (!res.ok) throw new Error(`Server returned ${res.status}`);

      const data = await res.json();
      showTyping(false);
      appendMessage(data.response, "bot");
    } catch (err) {
      console.error("Chat request failed:", err);
      showTyping(false);
      appendMessage(
        "Sorry, I couldn't reach the server. Please check your connection and try again.",
        "bot",
        true
      );
    } finally {
      setSending(false);
      els.input.focus();
    }
  }

  function openChat() {
    isOpen = true;
    els.window.classList.remove("chat-window--hidden");
    els.input.focus();
  }

  function closeChat() {
    isOpen = false;
    els.window.classList.add("chat-window--hidden");
  }

  els.toggleBtn.addEventListener("click", () => (isOpen ? closeChat() : openChat()));
  els.closeBtn.addEventListener("click", closeChat);

  els.form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = els.input.value.trim();
    if (!text || isSending) return;
    els.input.value = "";
    sendMessage(text);
  });

  // Enter key support is native via form submit; Shift+Enter not needed
  // since this is a single-line input by design.

  loadTheme();
})();
