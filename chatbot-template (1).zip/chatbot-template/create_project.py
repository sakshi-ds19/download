#!/usr/bin/env python3
"""
create_project.py
====================
ONE-COMMAND PROJECT GENERATOR.

Give this script a short CODE and a Company Name, and it creates a
brand-new, complete, standalone, ready-to-run chatbot project folder
(a full copy of this framework - backend, frontend, everything) already
pre-configured and branded for that company.

This is different from scripts/create_company.py, which only adds a new
company folder INSIDE the current multi-tenant project. This script
instead stamps out a whole independent project - useful when you want
to hand a self-contained folder/zip to a client or deploy each company
as its own separate app.

USAGE
-----
    python create_project.py <code> "<Company Name>"

EXAMPLE
-------
    python create_project.py mankdir "Mankdir Solutions"

This creates:

    ../mankdir-chatbot/
        app.py
        config.py
        chatbot/               (core framework, unchanged)
        companies/
            mankdir/
                theme.py               <- pre-filled with the company name
                data/company_data.txt  <- blank template ready to fill in
        templates/
        static/
        scripts/
        requirements.txt
        .env                    <- already set to COMPANY_CODE=mankdir
        .env.example
        README.md

The generated folder is 100% independent and immediately runnable:

    cd ../mankdir-chatbot
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    # add your GEMINI_API_KEY to .env
    uvicorn app:app --reload
"""

import re
import shutil
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR

CODE_PATTERN = re.compile(r"^[a-z0-9][a-z0-9\-_]*$")

# Files/folders copied verbatim into every new project - the reusable
# "brick" of the framework. `companies/` is deliberately excluded here
# because we generate a fresh, single company folder for the new project
# instead of copying the demo/example companies.
CORE_ITEMS = [
    "app.py",
    "config.py",
    "requirements.txt",
    ".env.example",
    "README.md",
    "chatbot",
    "templates",
    "static",
    "scripts",
]

THEME_TEMPLATE = '''"""
companies/{code}/theme.py
=========================
Global branding/theme configuration for {company_name}.

Edit these values to rebrand the chatbot. Every field here is
automatically picked up by the frontend via GET /theme - no HTML/CSS/JS
changes are ever required.
"""

# Branding
COMPANY_NAME = "{company_name}"
BOT_NAME = "Assistant"
LOGO_PATH = "/static/images/logo.png"
CHAT_ICON = "\U0001F4AC"

# Colors (used as CSS variables by the frontend)
PRIMARY_COLOR = "#4F46E5"
SECONDARY_COLOR = "#818CF8"
BACKGROUND_COLOR = "#F9FAFB"

# Typography
FONT_FAMILY = "'Inter', 'Segoe UI', sans-serif"

# Copy
WELCOME_MESSAGE = "Hi! How can I help you today?"
FOOTER_TEXT = "Powered by {company_name} AI"
'''

DATA_TEMPLATE = """Company Name: {company_name}

CEO:

Email:

Phone:

Office Address:

Working Hours:

Products:
-

Services:
-

Return Policy:


FAQs:

Q:
A:
"""

ENV_TEMPLATE = """COMPANY_CODE={code}
AI_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-2.0-flash
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o-mini
HOST=0.0.0.0
PORT=8000
DEBUG=false
MAX_MESSAGE_LENGTH=1000
AI_TIMEOUT_SECONDS=20
AI_MAX_OUTPUT_TOKENS=512
"""


def slugify_check(code: str) -> str:
    code = code.strip().lower()
    if not CODE_PATTERN.match(code):
        print(
            f"Error: '{code}' is not a valid code.\n"
            f"Use lowercase letters, numbers, hyphens, or underscores "
            f"(e.g. 'mankdir', 'data-ch', 'acme_corp')."
        )
        sys.exit(1)
    return code


def create_project(code: str, company_name: str, dest_parent: Path) -> Path:
    project_dir = dest_parent / f"{code}-chatbot"

    if project_dir.exists():
        print(f"Error: '{project_dir}' already exists. Choose a different code or location.")
        sys.exit(1)

    project_dir.mkdir(parents=True)

    # 1. Copy the reusable core framework
    for item in CORE_ITEMS:
        src = PROJECT_ROOT / item
        dst = project_dir / item
        if not src.exists():
            print(f"Warning: expected core file/folder missing: {src}")
            continue
        if src.is_dir():
            shutil.copytree(
                src, dst,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
            )
        else:
            shutil.copy2(src, dst)

    # 2. Create logs/ (empty, gitkeep only)
    logs_dir = project_dir / "logs"
    logs_dir.mkdir(exist_ok=True)
    (logs_dir / ".gitkeep").write_text("", encoding="utf-8")

    # 3. Generate a fresh, pre-branded company folder
    company_dir = project_dir / "companies" / code
    data_dir = company_dir / "data"
    data_dir.mkdir(parents=True)
    (company_dir / "theme.py").write_text(
        THEME_TEMPLATE.format(code=code, company_name=company_name), encoding="utf-8"
    )
    (data_dir / "company_data.txt").write_text(
        DATA_TEMPLATE.format(company_name=company_name), encoding="utf-8"
    )

    # 4. Write a ready-to-use .env pointing at the new company
    (project_dir / ".env").write_text(ENV_TEMPLATE.format(code=code), encoding="utf-8")

    # 5. Copy the placeholder logo if present
    src_logo = PROJECT_ROOT / "static" / "images" / "logo.png"
    if src_logo.exists():
        shutil.copy2(src_logo, project_dir / "static" / "images" / "logo.png")

    return project_dir


def main() -> None:
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    raw_code = sys.argv[1]
    company_name = sys.argv[2]
    dest_parent = Path(sys.argv[3]) if len(sys.argv) > 3 else PROJECT_ROOT.parent

    code = slugify_check(raw_code)
    project_dir = create_project(code, company_name, dest_parent)

    print(f"\n✅ Standalone chatbot project created at:\n   {project_dir}\n")
    print("Next steps:")
    print(f"   cd {project_dir}")
    print("   python -m venv .venv && source .venv/bin/activate")
    print("   pip install -r requirements.txt")
    print("   # edit .env and add your real GEMINI_API_KEY")
    print(f"   # edit companies/{code}/theme.py and companies/{code}/data/company_data.txt")
    print("   uvicorn app:app --reload\n")


if __name__ == "__main__":
    main()
