"""
companies/demo/theme.py
=========================
Global branding/theme configuration for THIS company only.

This is the ONE file you edit to fully rebrand the chatbot for a new
company (colors, name, logo, messages, footer). The entire frontend UI
pulls these values via GET /theme - no HTML/CSS/JS changes needed.

To create a new company, don't edit this file directly - run:
    python scripts/create_company.py <code> "Company Name"
which generates a fresh copy of this file under companies/<code>/theme.py
for you to customize.
"""

# Branding
COMPANY_NAME = "Designer Hub"
BOT_NAME = "Diva"
LOGO_PATH = "/static/images/logo.png"
CHAT_ICON = "💬"

# Colors (used as CSS variables by the frontend)
PRIMARY_COLOR = "#4F46E5"      # main brand color (header, buttons, user bubble)
SECONDARY_COLOR = "#818CF8"    # accents, hover states
BACKGROUND_COLOR = "#F9FAFB"   # chat window background

# Typography
FONT_FAMILY = "'Inter', 'Segoe UI', sans-serif"

# Copy
WELCOME_MESSAGE = "Hi there! 👋 I'm Diva, Designer Hub's assistant. How can I help you today?"
FOOTER_TEXT = "Powered by Designer Hub AI"
