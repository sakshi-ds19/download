"""
ai_provider.py
===============
Defines the abstract contract every AI provider must implement, plus a
factory that returns the correct concrete provider based on config.

This is the extensibility seam required by the project spec: adding
OpenAI, Claude, Azure OpenAI, Ollama, Llama, or DeepSeek later means
writing ONE new class that implements `AIProvider` and registering it
in `get_ai_provider()`. Nothing in routes.py, prompt_manager.py, or the
frontend needs to change.
"""

from abc import ABC, abstractmethod


class AIProviderError(Exception):
    """Raised when an AI provider fails to produce a response
    (auth error, timeout, network failure, malformed response, etc.)."""


class AIProvider(ABC):
    """Abstract base class for all AI/LLM providers.

    Every concrete provider (Gemini, OpenAI, Claude, ...) must implement
    `generate_response`, taking a system prompt + user message and
    returning plain text. Keeping the interface this narrow is what
    lets `routes.py` stay provider-agnostic.
    """

    @abstractmethod
    def generate_response(self, system_prompt: str, user_message: str) -> str:
        """Generate an AI response.

        Args:
            system_prompt: Instructions + company knowledge base context.
            user_message: The end user's question.

        Returns:
            The model's text response.

        Raises:
            AIProviderError: On any failure calling the underlying API.
        """
        raise NotImplementedError


def get_ai_provider() -> AIProvider:
    """Factory that returns the active AIProvider based on config.AI_PROVIDER.

    To add a new provider:
        1. Create `chatbot/<name>_provider.py` implementing `AIProvider`.
        2. Import it here and add an elif branch for its config key.
        3. Set AI_PROVIDER=<name> in .env.

    No other file in the project needs to change.
    """
    import config as app_config

    provider = app_config.AI_PROVIDER

    if provider == "gemini":
        from chatbot.gemini_provider import GeminiProvider
        return GeminiProvider(
            api_key=app_config.GEMINI_API_KEY,
            model=app_config.GEMINI_MODEL,
            timeout=app_config.AI_TIMEOUT_SECONDS,
            max_output_tokens=app_config.AI_MAX_OUTPUT_TOKENS,
        )

    # ------------------------------------------------------------------
    # Future providers plug in exactly like this:
    #
    # elif provider == "openai":
    #     from chatbot.openai_provider import OpenAIProvider
    #     return OpenAIProvider(api_key=app_config.OPENAI_API_KEY, ...)
    #
    # elif provider == "claude":
    #     from chatbot.claude_provider import ClaudeProvider
    #     return ClaudeProvider(...)
    #
    # elif provider == "ollama":
    #     from chatbot.ollama_provider import OllamaProvider
    #     return OllamaProvider(...)
    # ------------------------------------------------------------------

    raise ValueError(
        f"Unknown AI_PROVIDER '{provider}'. "
        f"Supported: gemini (openai/claude/ollama can be added in ai_provider.py)"
    )
