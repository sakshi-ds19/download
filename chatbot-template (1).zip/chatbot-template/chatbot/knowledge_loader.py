"""
knowledge_loader.py
=====================
Loads a company's knowledge base as plain text for the prompt manager.

Today this reads a `.txt` file. The `KnowledgeLoader` interface is
deliberately narrow (one method: `load() -> str`) so that later this can
be swapped for a PDF loader, a database query, an Excel/Word parser, a
live website scraper, or a full RAG retriever - without touching
routes.py, prompt_manager.py, or the frontend at all.
"""

import logging
from abc import ABC, abstractmethod
from pathlib import Path

logger = logging.getLogger("chatbot")


class KnowledgeLoaderError(Exception):
    """Raised when the knowledge base cannot be loaded."""


class KnowledgeLoader(ABC):
    """Abstract interface for any knowledge base source."""

    @abstractmethod
    def load(self) -> str:
        """Return the knowledge base content as plain text.

        Raises:
            KnowledgeLoaderError: if the source is missing or unreadable.
        """
        raise NotImplementedError


class TextFileKnowledgeLoader(KnowledgeLoader):
    """Loads company knowledge from a plain `.txt` file.

    This is the default/starter implementation described in the project
    spec (`data/company_data.txt`).
    """

    def __init__(self, file_path: Path) -> None:
        self._file_path = file_path

    def load(self) -> str:
        if not self._file_path.exists():
            raise KnowledgeLoaderError(
                f"Knowledge base file not found: {self._file_path}"
            )
        try:
            return self._file_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise KnowledgeLoaderError(
                f"Could not read knowledge base file: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# Future loader stubs (uncomment / implement when needed).
# Each only needs to implement `load() -> str` to slot into the framework.
# ---------------------------------------------------------------------------
#
# class PDFKnowledgeLoader(KnowledgeLoader):
#     """Extracts text from one or more PDF files."""
#     ...
#
# class DatabaseKnowledgeLoader(KnowledgeLoader):
#     """Pulls structured company info from a SQL/NoSQL database."""
#     ...
#
# class ExcelKnowledgeLoader(KnowledgeLoader):
#     """Reads company info from an Excel workbook."""
#     ...
#
# class WebsiteKnowledgeLoader(KnowledgeLoader):
#     """Crawls/scrapes a live company website for FAQ-style content."""
#     ...
#
# class RAGKnowledgeLoader(KnowledgeLoader):
#     """Retrieves the most relevant chunks from a vector store per-query.
#     Note: for RAG, `load()` could accept the user query and return only
#     the relevant chunks instead of the whole document - the interface
#     can be extended with an optional `query` parameter when needed."""
#     ...


def get_knowledge_loader(company_dir: Path) -> KnowledgeLoader:
    """Factory returning the appropriate loader for a company.

    Currently always returns a TextFileKnowledgeLoader pointed at
    `<company_dir>/data/company_data.txt`. Swap the returned class here
    to change the knowledge source for ALL companies, or extend this
    factory to pick a loader per-company (e.g. based on a config flag)
    without touching any other file.
    """
    file_path = company_dir / "data" / "company_data.txt"
    return TextFileKnowledgeLoader(file_path)
