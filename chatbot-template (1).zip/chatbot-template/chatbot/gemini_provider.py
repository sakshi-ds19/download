"""
gemini_provider.py
====================
Concrete implementation of AIProvider backed by Google's Gemini API.
"""

import logging

from chatbot.ai_provider import AIProvider, AIProviderError

logger = logging.getLogger("chatbot")


class GeminiProvider(AIProvider):
    """Google Gemini implementation of the AIProvider interface."""

    def __init__(
        self,
        api_key: str,
        model: str = "gemini-2.0-flash",
        timeout: int = 20,
        max_output_tokens: int = 512,
    ) -> None:
        """
        Args:
            api_key: Gemini API key (from GEMINI_API_KEY env var).
            model: Gemini model name.
            timeout: Request timeout in seconds.
            max_output_tokens: Cap on generated response length.
        """
        if not api_key:
            raise AIProviderError(
                "GEMINI_API_KEY is missing. Add it to your .env file."
            )

        self._api_key = api_key
        self._model = model
        self._timeout = timeout
        self._max_output_tokens = max_output_tokens

        try:
            import google.generativeai as genai
        except ImportError as exc:
            raise AIProviderError(
                "google-generativeai package is not installed. "
                "Run: pip install google-generativeai"
            ) from exc

        genai.configure(api_key=self._api_key)
        self._genai = genai
        self._client = genai.GenerativeModel(model_name=self._model)

    def generate_response(self, system_prompt: str, user_message: str) -> str:
        """Call Gemini and return the text response.

        Raises:
            AIProviderError: on timeout, API error, empty response, etc.
        """
        try:
            response = self._client.generate_content(
                [
                    {"role": "user", "parts": [system_prompt]},
                    {"role": "model", "parts": ["Understood. I will follow these instructions."]},
                    {"role": "user", "parts": [user_message]},
                ],
                generation_config=self._genai.types.GenerationConfig(
                    max_output_tokens=self._max_output_tokens,
                    temperature=0.3,
                ),
                request_options={"timeout": self._timeout},
            )
        except Exception as exc:  # noqa: BLE001 - normalize all provider errors
            logger.error("Gemini API call failed: %s", exc)
            raise AIProviderError(f"Gemini API error: {exc}") from exc

        text = getattr(response, "text", None)
        if not text:
            logger.warning("Gemini returned an empty response.")
            raise AIProviderError("Gemini returned an empty response.")

        return text.strip()
