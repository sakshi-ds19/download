"""Chatbot core package: AI provider abstraction, prompt management,
knowledge loading, and API routes."""
