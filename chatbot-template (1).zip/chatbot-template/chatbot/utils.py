"""
utils.py
=========
Small shared helpers: input validation/sanitization and consistent
user-friendly error message formatting.
"""

import html


def sanitize_message(message: str, max_length: int) -> str:
    """Trim, HTML-escape, and length-limit a user-submitted chat message.

    Args:
        message: Raw user input.
        max_length: Maximum allowed character length.

    Returns:
        A safe, trimmed string.
    """
    cleaned = html.escape(message.strip())
    return cleaned[:max_length]


def friendly_error(context: str) -> str:
    """Return a polite, non-technical error message for the given context.

    Args:
        context: One of "empty", "timeout", "auth", "provider", "knowledge",
            or "unknown".
    """
    messages = {
        "empty": "Please type a question before sending.",
        "timeout": "That took a bit too long to answer. Please try again in a moment.",
        "auth": "Our assistant is temporarily unavailable due to a configuration issue. Please try again later or contact support.",
        "provider": "Sorry, I'm having trouble generating a response right now. Please try again shortly.",
        "knowledge": "I don't have company information loaded right now, so I can't answer that yet. Please contact us directly for help.",
        "unknown": "Something went wrong on our end. Please try again, and contact support if the problem continues.",
    }
    return messages.get(context, messages["unknown"])
