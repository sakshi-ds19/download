"""
company_loader.py
====================
Resolves a company_code into its Theme + knowledge base.

This is what makes the framework multi-tenant: each company lives under
`companies/<code>/` with its own `theme.py` and `data/company_data.txt`.
Nothing about the FastAPI app, routes, or frontend needs to change to
onboard a new company - only a new folder needs to exist (see
scripts/create_company.py, which generates it for you).
"""

import importlib.util
import logging
from dataclasses import dataclass
from pathlib import Path

from chatbot.knowledge_loader import get_knowledge_loader, KnowledgeLoaderError

logger = logging.getLogger("chatbot")


@dataclass
class Theme:
    """Typed representation of a company's branding/theme values.

    Every field maps 1:1 to a value the frontend needs to render the
    branded chatbot UI. See companies/demo/theme.py for the source of
    truth on defaults / an example.
    """

    company_name: str = "Your Company"
    bot_name: str = "Assistant"
    logo_path: str = "/static/images/logo.png"
    primary_color: str = "#4F46E5"
    secondary_color: str = "#818CF8"
    background_color: str = "#F9FAFB"
    font_family: str = "'Inter', sans-serif"
    welcome_message: str = "Hi! How can I help you today?"
    chat_icon: str = "💬"
    footer_text: str = "Powered by AI"

    def to_dict(self) -> dict:
        return {
            "company_name": self.company_name,
            "bot_name": self.bot_name,
            "logo_path": self.logo_path,
            "primary_color": self.primary_color,
            "secondary_color": self.secondary_color,
            "background_color": self.background_color,
            "font_family": self.font_family,
            "welcome_message": self.welcome_message,
            "chat_icon": self.chat_icon,
            "footer_text": self.footer_text,
        }


class CompanyNotFoundError(Exception):
    """Raised when the configured COMPANY_CODE has no matching folder."""


def _load_theme_module(company_dir: Path):
    """Dynamically import companies/<code>/theme.py as a module."""
    theme_path = company_dir / "theme.py"
    if not theme_path.exists():
        raise CompanyNotFoundError(
            f"No theme.py found for company at {company_dir}. "
            f"Run scripts/create_company.py to scaffold it."
        )
    spec = importlib.util.spec_from_file_location(
        f"companies.{company_dir.name}.theme", theme_path
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


def load_theme(company_dir: Path) -> Theme:
    """Load and validate the Theme for a company directory.

    Falls back to Theme defaults for any field the company's theme.py
    does not define, so a minimal theme.py still works.
    """
    module = _load_theme_module(company_dir)
    values = {
        field: getattr(module, field.upper(), None)
        for field in Theme.__dataclass_fields__
    }
    values = {k: v for k, v in values.items() if v is not None}
    return Theme(**values)


def load_knowledge_base(company_dir: Path) -> str:
    """Load the raw knowledge base text for a company directory.

    Returns an empty string (rather than raising) if missing, so the
    app can still boot and respond with a graceful "I don't know" -
    per the "never hallucinate, degrade gracefully" requirement.
    """
    loader = get_knowledge_loader(company_dir)
    try:
        return loader.load()
    except KnowledgeLoaderError as exc:
        logger.error("Knowledge base load failed for %s: %s", company_dir, exc)
        return ""
