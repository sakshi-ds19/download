"""
routes.py
==========
FastAPI route definitions for the chatbot API.

Endpoints:
    POST /chat   -> { "message": str }  =>  { "response": str }
    GET  /theme  -> current company's theme configuration (JSON)

Business logic here is intentionally provider-agnostic and
company-agnostic: it always goes through `get_ai_provider()` and the
active company's theme/knowledge base, so swapping either has zero
impact on this file.
"""

import logging

from fastapi import APIRouter
from pydantic import BaseModel, Field

import config as app_config
from chatbot.ai_provider import get_ai_provider, AIProviderError
from chatbot.company_loader import load_theme, load_knowledge_base, CompanyNotFoundError
from chatbot.prompt_manager import build_system_prompt
from chatbot.utils import sanitize_message, friendly_error

logger = logging.getLogger("chatbot")
router = APIRouter()


class ChatRequest(BaseModel):
    """Incoming payload for POST /chat."""
    message: str = Field(..., description="The user's question")


class ChatResponse(BaseModel):
    """Outgoing payload for POST /chat."""
    response: str


@router.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    """Handle a single chat turn: validate input, ground the AI in the
    active company's knowledge base, call the AI provider, and return
    its response.

    Never raises HTTP 500 with raw internals - all failure modes are
    translated into polite, user-facing messages per the error handling
    requirement.
    """
    company_dir = app_config.get_company_dir()

    # 1. Validate input
    message = sanitize_message(request.message, app_config.MAX_MESSAGE_LENGTH)
    if not message:
        return ChatResponse(response=friendly_error("empty"))

    # 2. Load company theme + knowledge base
    try:
        theme = load_theme(company_dir)
    except CompanyNotFoundError as exc:
        logger.error("Company config error: %s", exc)
        return ChatResponse(response=friendly_error("unknown"))

    knowledge_base = load_knowledge_base(company_dir)
    if not knowledge_base.strip():
        return ChatResponse(response=friendly_error("knowledge"))

    # 3. Build grounded system prompt
    system_prompt = build_system_prompt(
        company_name=theme.company_name,
        bot_name=theme.bot_name,
        knowledge_base=knowledge_base,
    )

    # 4. Call the AI provider
    try:
        provider = get_ai_provider()
        answer = provider.generate_response(system_prompt, message)
    except AIProviderError as exc:
        logger.error("AI provider error: %s", exc)
        text = str(exc).lower()
        if "api key" in text or "auth" in text or "permission" in text:
            return ChatResponse(response=friendly_error("auth"))
        if "timeout" in text:
            return ChatResponse(response=friendly_error("timeout"))
        return ChatResponse(response=friendly_error("provider"))
    except Exception as exc:  # noqa: BLE001 - final safety net
        logger.exception("Unexpected error in /chat: %s", exc)
        return ChatResponse(response=friendly_error("unknown"))

    return ChatResponse(response=answer)


@router.get("/theme")
def get_theme() -> dict:
    """Return the active company's theme configuration as JSON.

    The frontend fetches this on load to brand itself (logo, colors,
    company name, welcome message, etc.) without any code changes.
    """
    company_dir = app_config.get_company_dir()
    try:
        theme = load_theme(company_dir)
    except CompanyNotFoundError as exc:
        logger.error("Theme load failed: %s", exc)
        from chatbot.company_loader import Theme
        theme = Theme()  # safe fallback so the UI still renders
    return theme.to_dict()


@router.get("/health")
def health_check() -> dict:
    """Simple liveness/readiness probe for deployment platforms."""
    return {"status": "ok", "company_code": app_config.COMPANY_CODE}
