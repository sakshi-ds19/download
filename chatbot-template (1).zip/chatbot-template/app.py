"""
app.py
=======
FastAPI application entrypoint for the White-Label AI Chatbot Framework.

Run with:
    uvicorn app:app --host 0.0.0.0 --port 8000 --reload

The active company is selected purely via the COMPANY_CODE environment
variable (see config.py / .env) - this file never hardcodes any
company-specific values.
"""

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

import config
from chatbot.routes import router as chat_router

logger = config.setup_logging()

app = FastAPI(
    title="White-Label AI Chatbot Framework",
    description="A reusable, multi-tenant AI chatbot backend powered by Google Gemini.",
    version="1.0.0",
)

# Static assets (css/js/images) and Jinja2 templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Chat + theme API routes
app.include_router(chat_router)


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    """Serve the chatbot widget's host page."""
    return templates.TemplateResponse(
        "index.html", {"request": request, "company_code": config.COMPANY_CODE}
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Catch-all so no raw stack trace ever reaches the client."""
    logger.exception("Unhandled exception on %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=500,
        content={"detail": "Something went wrong. Please try again shortly."},
    )


@app.on_event("startup")
def on_startup() -> None:
    logger.info(
        "Chatbot starting | company_code=%s | ai_provider=%s",
        config.COMPANY_CODE,
        config.AI_PROVIDER,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host=config.HOST, port=config.PORT, reload=config.DEBUG)
