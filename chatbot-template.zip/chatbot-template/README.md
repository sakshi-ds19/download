# White-Label AI Chatbot Framework

A reusable, production-ready AI chatbot framework built with **FastAPI** +
**Google Gemini**. The same codebase can be branded and deployed for any
number of companies by only editing a small per-company **theme** and
**knowledge base file** — never the core code.

The chatbot answers questions **only** using the company information you
give it (CEO, contact info, hours, products, services, FAQs...). If the
answer isn't in the knowledge base, it politely says so instead of making
something up.

---

## 1. Key Idea: Multi-Tenant by Folder

Each company lives in its own folder under `companies/`:

```
companies/
  demo/
    theme.py              <- colors, name, bot persona, welcome message
    data/
      company_data.txt    <- CEO, contact, hours, products, FAQs...
  data-ch/                <- another company, generated the same way
    theme.py
    data/company_data.txt
```

The app reads the `COMPANY_CODE` environment variable and loads
`companies/<COMPANY_CODE>/` at runtime. **Nothing else changes** — same
FastAPI backend, same HTML/CSS/JS frontend, same prompt logic.

### Generate a new company in one command

Instead of manually creating folders, use the built-in generator:

```bash
python scripts/create_company.py <code> "<Company Display Name>"
```

Example:

```bash
python scripts/create_company.py data-ch "Data Chatbot Inc"
```

This instantly creates:

```
companies/data-ch/theme.py
companies/data-ch/data/company_data.txt
```

pre-filled with sensible defaults and empty fields ready for you to fill
in. The script prints the exact next steps, including the `.env` line to
add (`COMPANY_CODE=data-ch`).

That's the whole onboarding flow for a brand-new client:

1. `python scripts/create_company.py <code> "<Name>"`
2. Fill in `companies/<code>/theme.py` (colors, logo, bot name...)
3. Fill in `companies/<code>/data/company_data.txt` (real company facts)
4. Set `COMPANY_CODE=<code>` in `.env`
5. Run the app

---

## 2. Project Structure

```
chatbot-template/
├── app.py                    # FastAPI entrypoint
├── config.py                 # Env var loading, active company resolution, logging
├── requirements.txt
├── .env.example
│
├── chatbot/
│   ├── ai_provider.py        # Abstract AIProvider interface + factory
│   ├── gemini_provider.py    # Google Gemini implementation
│   ├── prompt_manager.py     # Builds the anti-hallucination system prompt
│   ├── knowledge_loader.py   # Abstract KnowledgeLoader (txt today, PDF/DB/RAG later)
│   ├── company_loader.py     # Resolves company_code -> Theme + knowledge base
│   ├── routes.py             # POST /chat, GET /theme, GET /health
│   └── utils.py               # Input sanitization, friendly error messages
│
├── companies/
│   └── demo/
│       ├── theme.py           # Example company theme (Designer Hub)
│       └── data/company_data.txt
│
├── scripts/
│   └── create_company.py     # Generator: code + name -> new company folder
│
├── templates/
│   └── index.html            # Widget host page
│
├── static/
│   ├── css/style.css          # Theme-driven CSS (uses CSS variables)
│   ├── js/chat.js             # Chat flow logic
│   └── images/logo.png
│
├── logs/                      # app.log written here at runtime
└── README.md
```

---

## 3. Setup & Run

### Step 1 — Install dependencies

```bash
cd chatbot-template
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Step 2 — Configure environment

```bash
cp .env.example .env
```

Edit `.env`:

```
COMPANY_CODE=demo
GEMINI_API_KEY=your_real_key_here
```

Get a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).

### Step 3 — Run the app

```bash
uvicorn app:app --reload
```

Open **http://localhost:8000** — you'll see the demo host page with a
floating chat button in the bottom-right corner (branded as "Designer
Hub" using the included `companies/demo/` example).

---

## 4. Deploying for a New Company

```bash
# 1. Scaffold the folder
python scripts/create_company.py acme "Acme Corporation"

# 2. Fill in the generated files
#    companies/acme/theme.py            <- brand colors, logo, bot name
#    companies/acme/data/company_data.txt  <- real company facts/FAQs

# 3. Point the app at it
echo "COMPANY_CODE=acme" >> .env    # or edit .env manually

# 4. Restart the app
uvicorn app:app --reload
```

The entire UI (colors, logo, welcome message, footer) and all chatbot
answers now reflect Acme Corporation — with zero code changes.

> Running multiple companies at once (e.g. one process per client, or a
> path-based multi-tenant router) is a straightforward extension of
> `chatbot/company_loader.py` + `chatbot/routes.py`, since both already
> take a `company_code` parameter under the hood.

---

## 5. API Reference

### `POST /chat`

**Request**
```json
{ "message": "Who is your CEO?" }
```

**Response**
```json
{ "response": "The CEO of Designer Hub is Ananya Sharma." }
```

If the answer isn't in the knowledge base, the response politely says so
instead of guessing.

### `GET /theme`

Returns the active company's theme as JSON — used by the frontend to
brand itself on load.

### `GET /health`

Simple liveness check, returns `{"status": "ok", "company_code": "..."}`.

---

## 6. How Hallucination Is Prevented

`chatbot/prompt_manager.py` wraps every request in a strict system
prompt that instructs the model to:

- Answer **only** from the provided `COMPANY INFORMATION` block.
- Say "I don't have that information" when the answer isn't present.
- Never invent names, numbers, prices, or policies.
- Refuse to answer questions unrelated to the company.

The company's knowledge base text is injected fresh into that prompt on
every request — the model never uses outside/general knowledge for
factual claims about the business.

---

## 7. Extensibility

### Adding a new AI provider (OpenAI, Claude, Azure OpenAI, Ollama, Llama, DeepSeek...)

1. Create `chatbot/<name>_provider.py` implementing the `AIProvider`
   abstract class (one method: `generate_response`).
2. Register it in the `get_ai_provider()` factory in
   `chatbot/ai_provider.py`.
3. Set `AI_PROVIDER=<name>` in `.env`.

No changes needed in `routes.py`, `prompt_manager.py`, or the frontend.

### Swapping the knowledge base source (PDF, Database, Excel, Word, Website, RAG)

1. Implement a new `KnowledgeLoader` subclass in
   `chatbot/knowledge_loader.py` (one method: `load() -> str`).
2. Return it from `get_knowledge_loader()`.

Everything downstream (`prompt_manager`, `routes`, frontend) is
unaffected because they only ever see the resulting knowledge base text.

---

## 8. Error Handling

The framework returns polite, user-facing messages (never stack traces)
for:

- Empty/blank user message
- Missing or invalid `GEMINI_API_KEY`
- AI provider timeout
- AI provider/network failure
- Missing or unreadable `company_data.txt`
- Any unexpected server error (caught by a global exception handler)

All errors are also logged to `logs/app.log` for debugging.

---

## 9. Tech Stack

- **Backend:** Python 3.10+, FastAPI, Uvicorn
- **Frontend:** HTML5, CSS3 (custom properties for theming), vanilla JavaScript
- **AI:** Google Gemini API (`google-generativeai`), architected for
  easy multi-provider support
- **Config:** `.env` via `python-dotenv` — no secrets in code

---

## 10. License

Use freely as a starting template for your own client projects.
